# app.py
from flask import Flask, render_template, request
import sqlite3
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

# Step 3: Set up the Database
def create_table():
    conn = sqlite3.connect('patients.db')
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            dob TEXT NOT NULL,
            id_number TEXT NOT NULL,
            address TEXT NOT NULL,
            county TEXT NOT NULL,
            sub_county TEXT NOT NULL,
            telephone TEXT NOT NULL,
            email TEXT NOT NULL,
            gender TEXT NOT NULL,
            marital_status TEXT NOT NULL,
            next_of_kin_name TEXT NOT NULL,
            next_of_kin_dob TEXT NOT NULL,
            next_of_kin_id_number TEXT NOT NULL,
            next_of_kin_gender TEXT NOT NULL,
            next_of_kin_relationship TEXT NOT NULL,
            next_of_kin_telephone TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

create_table()

# Step 4: Create the Patient Registration Form
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get form data
        patient_data = request.form
        patient_id = save_to_database(patient_data)
        send_email(patient_data['email'], patient_id)
        return f"Patient Registration Successful. Patient ID: {patient_id}"
    return render_template('registration_form.html')

# Step 5: Save Data to the Database
def save_to_database(data):
    conn = sqlite3.connect('patients.db')
    cur = conn.cursor()
    cur.execute('''
        INSERT INTO patients (name, dob, id_number, address, county, sub_county, telephone, email, gender, marital_status, next_of_kin_name, next_of_kin_dob, next_of_kin_id_number, next_of_kin_gender, next_of_kin_relationship, next_of_kin_telephone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        data['name'],
        data['dob'],
        data['id_number'],
        data['address'],
        data['county'],
        data['sub_county'],
        data['telephone'],
        data['email'],
        data['gender'],
        data['marital_status'],
        data['next_of_kin_name'],
        data['next_of_kin_dob'],
        data['next_of_kin_id_number'],
        data['next_of_kin_gender'],
        data['next_of_kin_relationship'],
        data['next_of_kin_telephone']
    ))
    conn.commit()
    patient_id = cur.lastrowid
    conn.close()
    return patient_id

# Step 6: Send Email to the Patient
def send_email(to_email, patient_id):
    # Replace these values with your actual email and password
    email_sender = 'okothmoses258@gmail.com'
    email_password = 'wagaka001'
    
    subject = 'Patient Registration Confirmation'
    message = f"Thank you for registering! Your Patient Reference Number is: {patient_id}"

    msg = MIMEMultipart()
    msg['From'] = email_sender
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(message, 'plain'))

    # Use SSL/TLS for secure connection
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()

    try:
        server.login(email_sender, email_password)
        server.sendmail(email_sender, to_email, msg.as_string())
        print("Email sent successfully!")
    except smtplib.SMTPAuthenticationError as e:
        print(f"Error: Unable to send email. Authentication failed: {e}")
    except Exception as e:
        print(f"Error: Unable to send email: {e}")

    server.quit()



if __name__ == '__main__':
    app.run(debug=True)
